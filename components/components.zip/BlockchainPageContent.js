"use client";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import BlockchainHeroNew from "@/components/BlockchainHeroNew";
import BlockchainServicesGrid from "@/components/BlockchainServicesGrid";
import BlockchainTrustedPlatform from "@/components/BlockchainTrustedPlatform";
import BlockchainSaveSwap from "@/components/BlockchainSaveSwap";
import BlockchainInvestingTrading from "@/components/BlockchainInvestingTrading";
import BlockchainWalletBenefits from "@/components/BlockchainWalletBenefits";
import BlockchainTokenDeploy from "@/components/BlockchainTokenDeploy";
import BlockchainTechStack from "@/components/BlockchainTechStack";
import BlockchainProcess from "@/components/BlockchainProcess";
import BlockchainIndustries from "@/components/BlockchainIndustries";
import BlockchainFAQ from "@/components/BlockchainFAQ";
import BlockchainCTA from "@/components/BlockchainCTA";

export default function BlockchainPageContent() {
  return (
    <div className="new-bc-page">
      <Header variant="light" />
      <main>
        <BlockchainHeroNew />
        <BlockchainTrustedPlatform />
        <BlockchainServicesGrid />
        <BlockchainSaveSwap />
        <BlockchainInvestingTrading />
        <BlockchainWalletBenefits />
        <BlockchainTokenDeploy />
        <BlockchainTechStack />
        <BlockchainProcess />
        <BlockchainIndustries />
        <BlockchainFAQ />
        <BlockchainCTA />
      </main>
      <Footer />
    </div>
  );
}
